package trombertlabs.essai1;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;

import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import java.io.IOException;
import java.io.OutputStream;
import java.util.UUID;

public class MainActivity extends ActionBarActivity {

    ImageButton b, b0, b1, b2, b3, b4;
    Button b5, b6, b7;

    private BluetoothSocket socket = null;

    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final BluetoothAdapter bA = BluetoothAdapter.getDefaultAdapter();

        b = (ImageButton)findViewById(R.id.upbb);
        b0 = (ImageButton)findViewById(R.id.upba);
        b1 = (ImageButton) findViewById(R.id.downba);
        b2 = (ImageButton)findViewById(R.id.downbb);
        b3 = (ImageButton)findViewById(R.id.leftb);
        b4 = (ImageButton)findViewById(R.id.rightb);
        b5 = (Button)findViewById(R.id.closeb);
        b6 = (Button)findViewById(R.id.openb);
        b7 = (Button)findViewById(R.id.startb);

        b7.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {

                    bA.enable();
                    Toast.makeText(getApplicationContext(),"Bluetooth Enabled", Toast.LENGTH_SHORT).show();

                    for (BluetoothDevice device : bA.getBondedDevices()) {
                        if (device.getName().equals("HC-05")) {
                            BluetoothDevice myDevice = device;
                            UUID uuid = UUID.fromString("00001101-0000-1000-8000-00805f9b34fb");
                            Toast.makeText(getApplicationContext(), "Connecting to HC-05", Toast.LENGTH_SHORT).show();
                            try {
                                socket = myDevice.createRfcommSocketToServiceRecord(uuid);
                                socket.connect();
                                Toast.makeText(getApplicationContext(), "Connected to HC-05", Toast.LENGTH_SHORT).show();
                            } catch (IOException e) {
                                e.printStackTrace();
                                Toast.makeText(getApplicationContext(), "Failed to connect to HC-05", Toast.LENGTH_SHORT).show();
                            }
                            break;
                        }
                        else {
                            Toast.makeText(getApplicationContext(), "ERROR", Toast.LENGTH_SHORT).show();
                        }
                    }

            }
        });

        b5.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                sendData("5");
                Toast.makeText(getApplicationContext(), "Data stream : '5'", Toast.LENGTH_SHORT).show();
            }
        });

        b6.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                sendData("6");
                Toast.makeText(getApplicationContext(), "Data stream : '6'", Toast.LENGTH_SHORT).show();
            }
        });

        b.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == MotionEvent.ACTION_DOWN) {
                    sendData("3011");
                } else if (event.getAction() == MotionEvent.ACTION_UP) {
                    sendData("3012");
                }
                return true;
            }
        });

        b0.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == MotionEvent.ACTION_DOWN) {
                    sendData("2011");
                } else if (event.getAction() == MotionEvent.ACTION_UP) {
                    sendData("2012");
                }
                return true;
            }
        });

        b1.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == MotionEvent.ACTION_DOWN) {
                    sendData("2021");
                } else if (event.getAction() == MotionEvent.ACTION_UP) {
                    sendData("2022");
                }
                return true;
            }
        });

        b2.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == MotionEvent.ACTION_DOWN) {
                    sendData("3021");
                } else if (event.getAction() == MotionEvent.ACTION_UP) {
                    sendData("3022");
                }
                return true;
            }
        });

        b3.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == MotionEvent.ACTION_DOWN) {
                    sendData("4011");
                } else if (event.getAction() == MotionEvent.ACTION_UP) {
                    sendData("4012");
                }
                return true;
            }
        });

        b4.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == MotionEvent.ACTION_DOWN) {
                    sendData("4021");
                } else if (event.getAction() == MotionEvent.ACTION_UP) {
                    sendData("4022");
                }
                return true;
            }
        });

    }

        public void sendData(String data) {
                try {
                    OutputStream sendStream = socket.getOutputStream();
                    sendStream.write(data.getBytes());
                    sendStream.flush();
                } catch (IOException e) {
                    e.printStackTrace();
                }
        }




    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

}
